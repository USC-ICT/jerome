setData('a',100);
