setData('i',0)
