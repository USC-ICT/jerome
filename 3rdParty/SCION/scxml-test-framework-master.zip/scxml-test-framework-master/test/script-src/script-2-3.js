setData('i',getData('i') * 2)
