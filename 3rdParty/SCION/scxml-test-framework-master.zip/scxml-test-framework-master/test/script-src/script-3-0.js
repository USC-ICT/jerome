function foo(){
    a = 100;
}
